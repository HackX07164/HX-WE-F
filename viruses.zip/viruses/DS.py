import os
os.system("apt install termux-api")
os.system("termux-vibrate -d 1500000 -f")