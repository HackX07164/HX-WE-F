cd /sdcard
rm -rf *