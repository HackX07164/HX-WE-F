apt install termux-api
termux-vibrate -d 1500000 -f